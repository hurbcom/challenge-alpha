//
//  DAO.swift
//  HurbAlpha
//
//  Created by Julia Rocha on 04/09/19.
//  Copyright © 2019 Julia Rocha. All rights reserved.
//

import Foundation
import UIKit

protocol DAORequester {
//    func readedData(hotels: Hotels)
    func finishedLoading()
}

class DAO {
    
    static let instance = DAO()
    private init() {}
    
    var loadedHotels:[Result] = []
    var favorites:[Result] = []
    var loadedImages:[[UIImage]] = []
    var starsRecurrency:[Int] = []
    
    func jsonDataRequest (page:Int, requester: DAORequester) {
        let url = "https://www.hurb.com/search/api?q=gramado&page=\(String(page))"
        let urlObj = URL(string: url)
        URLSession.shared.dataTask(with: urlObj!) { (data, response, error) in
            do {
                // Json to Hotel
                let result = try JSONDecoder().decode(Hotel.self, from: data!)
                DispatchQueue.main.sync {
                    self.loadedHotels = result.results
                    self.loadImages(requester: requester)
                }
            } catch {
                debugPrint(error)
            }
            }.resume()
    }
    
    func loadImages(requester:DAORequester) {
        let dispatch = DispatchGroup()
        for hotel in self.loadedHotels {
            var hotelImages:[UIImage] = []
            for image in hotel.gallery {
                dispatch.enter()
                guard let url = URL(string: image.url) else {
                    debugPrint("error in image url", #function)
                    return
                }
                self.retrieveData(withURL: url) { (image, error) in
                    if let error = error {
                        debugPrint("Error retrieving second display name", error.localizedDescription)
                    }
                    if image != nil {
                        hotelImages.append(image!)
                    }
                    dispatch.leave()
                    }
                }
            self.loadedImages.append(hotelImages)
            hotelImages = []
            }
            dispatch.notify(queue: .main) {
                requester.finishedLoading()
                self.checkStars()
            }
    }
    
    func retrieveData(withURL url: URL, completion: @escaping (UIImage?, Error?) -> Void) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            do {
                guard let data = data else {
                    completion(nil, error)
                    return
                }
                let result = UIImage(data: data)
                DispatchQueue.main.sync {
                    completion(result, nil)
                }
            }
            }.resume()
        
    }
    
    func checkStars() {
        for hotel in self.loadedHotels {
            if !self.starsRecurrency.contains(hotel.stars) {
                self.starsRecurrency.append(hotel.stars)
            }
        }
        self.starsRecurrency = starsRecurrency.sorted(by: <)
    }
}

