//
//  GeoLocation.swift
//  HurbAlpha
//
//  Created by Julia Rocha on 04/09/19.
//  Copyright © 2019 Julia Rocha. All rights reserved.
//

import Foundation

// MARK: - GeoLocation
struct GeoLocation: Codable {
    let lat, lon: Double
}
