//
//  FeedTableViewCell.swift
//  HurbAlpha
//
//  Created by Julia Rocha on 04/09/19.
//  Copyright © 2019 Julia Rocha. All rights reserved.
//
import UIKit
import Foundation

class TableViewCell: UITableViewCell {
    
    enum CellType {
        case package
        case hotel
    }
    
    
    var hotel: Hotel? = nil
    var type: CellType = .hotel
    var isFlagged: Bool = false
    
    
    //outlets
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    
   // stars - for hotels only
    @IBOutlet weak var star1: UIImageView!
    @IBOutlet weak var star2: UIImageView!
    @IBOutlet weak var star3: UIImageView!
    @IBOutlet weak var star4: UIImageView!
    @IBOutlet weak var star5: UIImageView!
    
    
    //outlets
    @IBOutlet weak var localLabel: UILabel!
    @IBOutlet weak var maxValorLabel: UILabel!
//    @IBOutlet weak var minValorLabel: UILabel!
    
    
    //amenities - for hotels or atribuites - for packages
    @IBOutlet weak var amenity1: UILabel!
    @IBOutlet weak var amenity2: UILabel!
    @IBOutlet weak var amenity3: UILabel!
 
    
    override func layoutSubviews() {
        //Shadows
        cellView.layer.shadowOffset = CGSize(width: 0, height: 0)
        cellView.layer.shadowColor = UIColor.black.cgColor
        cellView.layer.shadowOpacity = 0.23
        cellView.layer.shadowRadius = 4
        cellView.layer.cornerRadius = 12
        
        // Favorite Button image
        let imageSelected = UIImage(named: "favoritoSelected")
        favoriteButton.setImage(imageSelected, for: .selected)
        
        let imageNormal = UIImage(named: "favoriteFlag")
        favoriteButton.setImage(imageNormal, for: .normal)
        
    }
    
    func loadInfo(on item:Int) {
        let ref = DAO.instance.loadedHotels
        let imageRef = DAO.instance.loadedImages[item]
        self.nameLabel.text = ref[item].name
        self.nameLabel.textColor = .baseBlue
        self.localLabel.text = ref[item].address.city + " | " + ref[item].address.state
        self.maxValorLabel.text = (ref[item].price.currency ?? "BRL") +  String(ref[item].price.amountPerDay).split(separator: ".")[0] + "," + String(ref[item].price.amountPerDay).split(separator: ".")[1]
        let amenitiesList = ref[item].amenities
        switch amenitiesList.count {
        case 0:
            self.amenity1.isHidden = true
            self.amenity2.isHidden = true
            self.amenity3.isHidden = true
        case 1:
            self.amenity1.text = amenitiesList[0].name
            self.amenity2.isHidden = true
            self.amenity3.isHidden = true
        case 2:
            self.amenity1.text = amenitiesList[0].name
            self.amenity2.text = amenitiesList[1].name
            self.amenity3.isHidden = true
        default:
            self.amenity1.text = amenitiesList[0].name
            self.amenity2.text = amenitiesList[1].name
            self.amenity3.text = amenitiesList[2].name
        }
        let stars = [self.star1, self.star2, self.star3, self.star4, self.star5]
        for i in 0...ref[item].stars - 1 {
            stars[i]!.isHidden = false
        }
//        if DAO.instance.loadedImages.count != 0 {
//            self.photo.image = imageRef[0]
//            print(imageRef)
//        }
//        print(DAO.instance.loadedImages.description)
        
    }

    
    
    func addImageToView(imageURL: URL, imageView: UIImageView) {
        
        //adicionar foto
    }

    
    
    @IBAction func favoriteClicked(_ sender: Any) {
        isFlagged = !isFlagged
        switch isFlagged {
        case true:
            favoriteButton.isSelected = true
        case false:
            favoriteButton.isSelected = false
        }
    }
 
}
    
    

    

